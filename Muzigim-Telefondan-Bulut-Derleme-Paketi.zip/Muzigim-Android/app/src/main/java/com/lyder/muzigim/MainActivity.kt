package com.lyder.muzigim

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.core.content.ContextCompat
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF171F35)
private val Violet = Color(0xFFA78BFA)
private val Muted = Color(0xFF9BA8C2)

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({ mediaController = controllerFuture?.get() }, ContextCompat.getMainExecutor(this))
        setContent { MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Violet)) {
            MuzigimScreen(this, { mediaController }, ::playTrack)
        } }
    }

    private fun playTrack(track: Track) {
        val c = mediaController ?: return
        val uri = track.localPath?.let { Uri.fromFile(File(it)) } ?: Uri.parse(track.sourceUrl)
        c.setMediaItem(MediaItem.Builder().setUri(uri).setMediaId(track.id)
            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder().setTitle(track.title).setArtist(track.artist).build()).build())
        c.prepare(); c.play()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
private fun MuzigimScreen(context: Context, controller: () -> MediaController?, play: (Track) -> Unit) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("classical") }
    var searchText by remember { mutableStateOf("") }
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var downloads by remember { mutableStateOf<List<Track>>(loadDownloads(context)) }
    var favorites by remember { mutableStateOf(loadFavorites(context)) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Açık lisanslı müzikler aranıyor…") }
    var tab by remember { mutableStateOf("Keşfet") }
    var playingTitle by remember { mutableStateOf("Henüz parça seçilmedi") }
    var playingArtist by remember { mutableStateOf("Listeden müzik seçin") }

    fun search(term: String) {
        query = term
        tab = "Keşfet"
        loading = true
        message = "Müzikler aranıyor…"
        scope.launch {
            val result = withContext(Dispatchers.IO) { searchArchive(term) }
            tracks = result
            loading = false
            message = if (result.isEmpty()) "Uygun lisanslı kayıt bulunamadı. Başka bir kelime deneyin." else "${result.size} kayıt bulundu"
        }
    }
    LaunchedEffect(Unit) { search("classical") }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF20294A), Ink))).padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 24.dp, bottom = 20.dp)) {
            Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Violet, Color(0xFF4F46E5))), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                Text("♫", color = Color.White, fontSize = 27.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column { Text("Müziğim", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White); Text("Özgürce keşfet. Keyifle dinle.", color = Muted, fontSize = 12.sp) }
        }
        Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF2A3558), Color(0xFF171F35))), RoundedCornerShape(22.dp)).padding(20.dp)) {
            Text("AÇIK LİSANSLI MÜZİK ARŞİVİ", color = Violet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("Bugün hangi tınıya kulak verelim?", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
            Text("Ücretsiz ve lisans bilgisi bulunan kayıtları keşfet.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
        }
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = searchText, onValueChange = { searchText = it }, modifier = Modifier.weight(1f), placeholder = { Text("Şarkı, sanatçı veya tür ara…") }, singleLine = true)
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { if (searchText.isNotBlank()) search(searchText) }) { Icon(Icons.Default.Search, null) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("Keşfet", "Favoriler", "İndirilenler").forEach { label ->
                FilterChip(selected = tab == label, onClick = { tab = label }, label = { Text(label) })
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 13.dp, bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(when(tab) { "Favoriler" -> "Favorilerim"; "İndirilenler" -> "Çevrimdışı müzikler"; else -> "Müzikleri keşfet" }, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Text(if (loading) "Yükleniyor…" else message, color = Muted, fontSize = 11.sp)
        }
        val visible = when(tab) {
            "Favoriler" -> tracks.filter { favorites.contains(it.id) }
            "İndirilenler" -> downloads
            else -> tracks
        }
        LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
            if (visible.isEmpty()) item { Text(if (tab == "İndirilenler") "Henüz indirilen müzik yok." else "Sonuç bulunamadı.", color = Muted, modifier = Modifier.fillMaxWidth().padding(24.dp)) }
            items(visible, key = { it.id }) { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(16.dp)).padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).background(Color(0xFF303D62), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("♫", color = Color.White, fontSize = 22.sp) }
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(t.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                        Text(t.artist, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                        Text(t.license, color = Violet, fontSize = 10.sp)
                    }
                    IconButton(onClick = { favorites = favorites.toMutableSet().also { if (!it.add(t.id)) it.remove(t.id) }; saveFavorites(context, favorites) }) {
                        Icon(if (favorites.contains(t.id)) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = Violet)
                    }
                    IconButton(onClick = { play(t); playingTitle = t.title; playingArtist = t.artist }) { Icon(Icons.Default.PlayArrow, null, tint = Color.White) }
                    if (t.localPath == null) {
                        TextButton(onClick = {
                            scope.launch {
                                message = "İndiriliyor…"
                                val saved = withContext(Dispatchers.IO) { downloadTrack(context, t) }
                                if (saved != null) { downloads = loadDownloads(context); message = "İndirme tamamlandı" }
                                else message = "İndirme başarısız"
                            }
                        }) { Text("↓", color = Violet, fontSize = 19.sp) }
                    }
                }
            }
        }
        Column(Modifier.fillMaxWidth().background(Color(0xFF111A2D), RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(playingTitle, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1); Text(playingArtist, color = Muted, fontSize = 11.sp) }
                IconButton(onClick = { controller()?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                IconButton(onClick = { controller()?.let { if (it.isPlaying) it.pause() else it.play() } }) {
                    val isPlaying = controller()?.isPlaying == true
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Violet)
                }
                IconButton(onClick = { controller()?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
            }
        }
    }
}

private fun searchArchive(term: String): List<Track> {
    return try {
        val q = "mediatype:audio AND (${term.replace(Regex("[():]"), " ")})"
        val api = "https://archive.org/advancedsearch.php?q=${URLEncoder.encode(q, "UTF-8")}&fl[]=identifier&fl[]=title&fl[]=creator&fl[]=licenseurl&rows=30&page=1&output=json"
        val json = JSONObject(URL(api).openConnection().apply { connectTimeout = 12000; readTimeout = 12000 }.getInputStream().bufferedReader().readText())
        val docs = json.getJSONObject("response").getJSONArray("docs")
        val found = mutableListOf<Track>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.optString("identifier")
            if (id.isBlank()) continue
            try {
                val md = JSONObject(URL("https://archive.org/metadata/${URLEncoder.encode(id, "UTF-8")}").openConnection().apply { connectTimeout = 10000; readTimeout = 10000 }.getInputStream().bufferedReader().readText())
                val meta = md.optJSONObject("metadata") ?: continue
                val license = meta.optString("licenseurl", d.optString("licenseurl"))
                if (!allowedLicense(license)) continue
                val files = md.optJSONArray("files") ?: continue
                var fileName: String? = null
                for (j in 0 until files.length()) {
                    val f = files.getJSONObject(j)
                    val name = f.optString("name")
                    if (name.matches(Regex("(?i).+\\.(mp3|ogg|oga|wav|m4a)")) && !name.contains("__ia_thumb")) { fileName = name; break }
                }
                val file = fileName ?: continue
                val encoded = file.split("/").joinToString("/") { URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                found.add(Track(id, meta.optString("title", d.optString("title", "Untitled")), meta.optString("creator", d.optString("creator", "Sanatçı belirtilmemiş")), licenseLabel(license), "https://archive.org/download/$id/$encoded", "https://archive.org/details/$id"))
            } catch (_: Exception) {}
            if (found.size >= 15) break
        }
        found
    } catch (_: Exception) { emptyList() }
}

private fun allowedLicense(url: String): Boolean {
    val u = url.lowercase()
    return u.contains("creativecommons.org/publicdomain/zero") ||
        Regex("creativecommons\\.org/licenses/by(-sa|-nc|-nc-sa)?/").containsMatchIn(u)
}
private fun licenseLabel(url: String): String = when {
    url.contains("publicdomain/zero", true) -> "CC0 · Kamu malı"
    url.contains("by-nc-sa", true) -> "CC BY-NC-SA"
    url.contains("by-nc", true) -> "CC BY-NC"
    url.contains("by-sa", true) -> "CC BY-SA"
    else -> "CC BY"
}
private fun saveFavorites(c: Context, set: Set<String>) = c.getSharedPreferences("muzigim", 0).edit().putStringSet("favorites", set).apply()
private fun loadFavorites(c: Context): Set<String> = c.getSharedPreferences("muzigim", 0).getStringSet("favorites", emptySet()) ?: emptySet()
private fun loadDownloads(c: Context): List<Track> {
    val prefs = c.getSharedPreferences("muzigim", 0)
    val ids = prefs.getStringSet("download_ids", emptySet()) ?: emptySet()
    return ids.mapNotNull { id ->
        val raw = prefs.getString("track_$id", null) ?: return@mapNotNull null
        try {
            val j = JSONObject(raw)
            val path = j.getString("path")
            if (!File(path).exists()) return@mapNotNull null
            Track(id, j.getString("title"), j.getString("artist"), j.getString("license"), j.getString("url"), j.getString("detail"), path)
        } catch (_: Exception) { null }
    }
}
private fun downloadTrack(c: Context, t: Track): Track? {
    return try {
        val dir = File(c.filesDir, "music").apply { mkdirs() }
        val out = File(dir, "${t.id}.audio")
        URL(t.sourceUrl).openConnection().apply { connectTimeout = 15000; readTimeout = 30000 }.getInputStream().use { input ->
            out.outputStream().use { output -> input.copyTo(output) }
        }
        val saved = t.copy(localPath = out.absolutePath)
        val prefs = c.getSharedPreferences("muzigim", 0)
        val ids = (prefs.getStringSet("download_ids", emptySet()) ?: emptySet()).toMutableSet().apply { add(t.id) }
        prefs.edit().putStringSet("download_ids", ids).putString("track_${t.id}", JSONObject().apply {
            put("path", out.absolutePath); put("title", t.title); put("artist", t.artist); put("license", t.license)
            put("url", t.sourceUrl); put("detail", t.detailUrl)
        }.toString()).apply()
        saved
    } catch (_: Exception) { null }
}
