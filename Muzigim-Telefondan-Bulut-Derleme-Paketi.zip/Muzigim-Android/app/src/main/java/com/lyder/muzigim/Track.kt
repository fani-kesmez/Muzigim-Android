package com.lyder.muzigim

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val license: String,
    val sourceUrl: String,
    val detailUrl: String,
    val localPath: String? = null
)
