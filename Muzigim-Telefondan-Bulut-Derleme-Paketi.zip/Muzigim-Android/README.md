# Müziğim — Android uygulama kaynak projesi

Bu, Android Studio ile APK'ya derlenmek üzere hazırlanmış yerel Android/Kotlin projesidir. PWA değildir.

## Özellikler
- Internet Archive üzerinden açık lisans bilgisi olan ses kayıtlarını arama
- CC0, CC BY, CC BY-SA, CC BY-NC ve CC BY-NC-SA lisanslarını filtreleme
- Media3/ExoPlayer ile çalma; MediaSessionService sayesinde arka plan/ekran kapalı oynatma desteği
- Favoriler
- Uygulama özel alanına indirme ve çevrimdışı dinleme
- Türkçe arayüz

## APK oluşturma
1. Android Studio'yu bilgisayara kurun.
2. `Muzigim-Android` klasörünü Android Studio ile açın.
3. Gradle senkronizasyonunu tamamlayın (internet gerekir; Android SDK Platform 35 ve JDK 17).
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçin.
5. APK: `app/build/outputs/apk/debug/app-debug.apk`

Telefona aktarıp kurmak için APK dosyasını açın. Android, bilinmeyen uygulama yükleme izni isteyebilir.

## Önemli notlar
- Bu kaynak paketi APK değildir; bu çalışma ortamında Android SDK/Gradle derleyicisi bulunmadığından burada imzalı APK üretilemedi.
- Internet Archive metadata alanlarındaki lisans beyanları yükleyenlerce girilir; uygulama bunları otomatik filtreler, ancak kullanıcı her kaydın kaynak sayfasındaki lisans şartlarını ayrıca kontrol etmelidir.
- Kayıtların her zaman çevrimiçi olacağı veya oynatılacağı garanti edilmez. Arşiv API'si ve ağ bağlantısı gereklidir.
- İlk sürümde arama, favori, indirme ve yerel oynatma iskeleti bulunur. Üretim sürümü öncesinde cihaz testleri, hata/izin yönetimi ve lisans doğrulaması yapılmalıdır.


## Bilgisayarsız APK derleme (GitHub Actions)
Bu projeye `.github/workflows/android-apk.yml` eklendi. Bir GitHub hesabıyla telefondan GitHub web sitesinde boş bir repository oluşturup ZIP içeriğini yükleyin. `main` dalına yükleme yapıldığında Actions iş akışı otomatik çalışır. GitHub deposunda **Actions** sekmesinden `Build Müziğim APK` çalışmasının tamamlanmasını bekleyin. Tamamlanmış çalışmanın **Artifacts** bölümündeki `Muzigim-debug-apk` dosyasını indirin, ZIP'i açın ve içindeki `app-debug.apk` dosyasını Android telefonunuza kurun.

Not: Bu, test amaçlı debug APK'dır. Play Store dağıtımı için ayrı bir release anahtarıyla imzalama ve daha kapsamlı cihaz/lisans testleri gerekir. İlk derlemede GitHub Actions izinleri veya Gradle bağımlılıkları nedeniyle hata çıkarsa hata kaydına göre düzeltme gerekir.
